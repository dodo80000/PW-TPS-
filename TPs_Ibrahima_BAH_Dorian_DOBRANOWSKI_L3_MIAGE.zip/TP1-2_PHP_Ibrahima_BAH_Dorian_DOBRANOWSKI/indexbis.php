<?php
include("classes\Compte.php");
include("db.php");
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $compte = new Compte();
    $login = $_GET['login'];
    $password = $_GET['password'];

    $result = $compte->setLogin($login, $password);
    if (!$result) {
        echo "Login et/ou Password invalide(s)";
    } else {
        echo "Connexion à l'app réussie";
    }
    echo "<BR>";

    echo $compte->masquerLogin();
}
?>