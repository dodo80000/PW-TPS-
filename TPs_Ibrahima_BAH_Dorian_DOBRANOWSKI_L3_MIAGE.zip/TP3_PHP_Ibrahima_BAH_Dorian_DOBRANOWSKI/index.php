<?php
require_once __DIR__ . "/config/config.php";

// Toutes les routes disponibles de l'application
$routes = [
    'home'   => 'HomeController',
    'add'    => 'AddContactController',
    'view'   => 'ViewContactController',
    'edit'   => 'EditContactController',
    'delete' => 'DeleteContactController',
    'search' => 'SearchContactController',
];

$page = $_GET['page'] ?? 'home'; // Si $_GET['page'] est set alors on prend le nom de la page, par défaut on prend home

if (!isset($routes[$page])) { // Page non trouvé, on affiche une erreur
    http_response_code(404);
    echo "<h1>404 - Page introuvable</h1>";
    exit;
}

$controllerName = $routes[$page]; // ControllerName prends la valeur du nom du controlleur associé grace au tableau $routes
$controllerFile = __DIR__ . "/controllers/{$controllerName}.php"; // ControllerFile prends en valeur le chemin d'accès au controlleur associé

if (!file_exists($controllerFile)) { // Si le controlleur n'est pas trouvé on affiche une erreur
    http_response_code(500);
    echo "Erreur: contrôleur {$controllerName} introuvable.";
    exit;
}

require_once $controllerFile; // On appelle la page du controller 
$controller = new $controllerName(); // On crée une nouvelle instance de classe du controlleur recherché

if (isset($_GET['id'])) { // Si un id est set dans l'URL alors on est dans le cas d'un élément du CRUD (add, view etc.)
    $controller->index((int)$_GET['id']);
} else { // Sinon appel de la méthode index sans paramètre
    $controller->index();
}
