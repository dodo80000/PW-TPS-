<?php
define("DB_HOST", "db");
define("DB_NAME", "app_db");
define("DB_USER", "app_user");
define("DB_PASS", "app_pass");

define("BASE_URL", "/");

spl_autoload_register(function ($class) {
    $class = str_replace('\\', DIRECTORY_SEPARATOR, $class);
    $paths = [
        __DIR__ . '/../classes/' . $class . '.php',
        __DIR__ . '/../classes/DAO/' . $class . '.php',
        __DIR__ . '/../classes/Models/' . $class . '.php',
    ];
    foreach ($paths as $file) {
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

