<?php
class DeleteContactController {
    public function index(?int $id = null): void {
        if ($id === null) { header("Location: " . BASE_URL . "index.php?page=home"); exit; }

        $dao = new DAO();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (($_POST['confirm'] ?? '') === 'yes') {
                $c = $dao->findByIdContact($id);
                if ($c) { $dao->deleteContact($c); }
            }
            header("Location: " . BASE_URL . "index.php?page=home");
            exit;
        }

        $contact = $dao->findByIdContact($id);
        require __DIR__ . '/../views/delete_contact.php';
    }
}
