<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Ajouter un contact</title>
</head>

<body>
    <header>
    </header>
    <main>
        <h2>Modifier un contact</h2>

        <?php if ($contact): ?>
            <?php $infos = $contact->getContact(); ?>
            <form method="POST" action="">
                <label for="nom">Nom :</label>
                <input type="text" name="nom" id="nom" value="<?= htmlspecialchars($infos['nom']) ?>" required><br><br>

                <label for="prenom">Prénom :</label>
                <input type="text" name="prenom" id="prenom" value="<?= htmlspecialchars($infos['prenom']) ?>"
                    required><br><br>

                <label for="email">Email :</label>
                <input type="email" name="email" id="email" value="<?= htmlspecialchars($infos['email']) ?>"><br><br>

                <label for="telephone">Téléphone :</label>
                <input type="text" name="telephone" id="telephone"
                    value="<?= htmlspecialchars($infos['telephone']) ?>"><br><br>

                <button type="submit">Enregistrer les modifications</button>
            </form>
        <?php else: ?>
            <p>Contact introuvable.</p>
        <?php endif; ?>
        <p>
            <a href="../index.php">Retour à la liste</a>
        </p>


    </main>
</body>

</html>