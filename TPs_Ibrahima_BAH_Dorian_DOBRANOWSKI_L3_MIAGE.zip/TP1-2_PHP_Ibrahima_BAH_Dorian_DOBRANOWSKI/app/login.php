<!DOCTYPE html>
<html>
<?php if (isset($_GET['err'])): ?>
    <p style="color:red;">
        <?= htmlspecialchars($_GET['err']) // Sans cette fonction on peut afficher divers éléments en js ?>
    </p>
<?php endif; ?>

<body>
    <form method='POST' action='controleur1.php'>
        <input type='text' name='login'>
        <input type='password' name='password'>
        <button>OK</button>
    </form>
</body>

</html>