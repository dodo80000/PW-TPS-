<?php
class HomeController
{
    public function index(): void
    {
        $dao = new DAO();
        $contacts = $dao->findAllContact();
        require __DIR__ . '/../views/home.php';
    }
}
