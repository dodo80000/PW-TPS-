<?php
class ViewContactController {
    public function index(?int $id = null): void {
        if ($id === null) { header("Location: " . BASE_URL . "index.php?page=home"); exit; }
        $contact = (new DAO())->findByIdContact($id);
        require __DIR__ . '/../views/view_contact.php';
    }
}
