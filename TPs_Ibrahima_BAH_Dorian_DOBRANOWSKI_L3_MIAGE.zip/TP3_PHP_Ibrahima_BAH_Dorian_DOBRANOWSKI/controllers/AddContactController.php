<?php
class AddContactController {
    public function index(): void {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = trim($_POST['nom'] ?? ''); // trim permet de retirer les espaces du nom (afin d'éviter les erreurs de casse)
            $prenom = trim($_POST['prenom'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $telephone = trim($_POST['telephone'] ?? '');

            $contact = new Contact(0, $nom, $prenom, $email, $telephone);
            (new DAO())->createContact($contact);

            header("Location: " . BASE_URL . "index.php?page=home");
            exit;
        }
        require __DIR__ . '/../views/add_contact.php';
    }
}
