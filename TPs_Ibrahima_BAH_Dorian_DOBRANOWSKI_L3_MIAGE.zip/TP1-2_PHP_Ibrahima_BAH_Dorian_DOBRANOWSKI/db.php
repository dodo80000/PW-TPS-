<?php
$host = "localhost";
$dbname = "base_ddobranowski";
$user = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $password);
} catch (Exception $e) {
    echo 'Erreur lors de la connexion à la BDD', $e->getMessage(), "\n";
}
?>