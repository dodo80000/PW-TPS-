# TP – Classe PHP & Micro-site Login (Starter/Solution)

## Binôme

- Dorian Dobranowski
- Ibrahima BAH

## Description

Ce projet est un mini site PHP avec :

- Une classe `Compte` qui encapsule un utilisateur (login, password, méthodes utiles).
- Un formulaire de login (`app/login.php`).
- Un contrôleur (`app/controleur1.php`) qui appelle le modèle et redirige.
- Un modèle (`app/model.php`) qui gère la connexion à la base MySQL via PDO.
- Une page d’accueil (`app/home.php`) si l’authentification réussit.
- Un script `db.php` qui centralise la connexion PDO.
- Une table `users` créée à partir du script `db.sql`.
