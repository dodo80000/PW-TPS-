<?php
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/model.php';
require_once __DIR__ . '/../classes/Compte.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];

    $compte = new Compte($login, $password);

    if (!Compte::isValidLogin($compte->getLogin()) || !Compte::isStrongPassword($password)) {
        header("Location: login.php?err=Login ou mot de passe invalide");
        exit;
    }

    if (!existe($pdo, $compte->getLogin(), $password)) {
        header("Location: login.php?err=Identifiants invalides");
        exit;
    } else {
        header("Location: home.php");
        exit;
    }

}
