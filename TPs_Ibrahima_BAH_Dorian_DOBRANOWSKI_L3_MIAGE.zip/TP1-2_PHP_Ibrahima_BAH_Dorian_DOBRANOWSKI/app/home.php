<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="../src/style/home.css">
</head>

<body>
    <h1>Déja on voit une page !</h1>
    <img src='../public/img/miage.png'>
</body>

</html>