<?php
class Compte implements JsonSerializable
{
    private string $login; // Attribut login de type string (privé)
    private string $password; // Attribut password de type string (privé)

    private static int $count = 0; // Attribut count de type int, initialisé à 0 (privé)

    public function getLogin(): string
    { // Récupère le login d'un compte
        return $this->login;
    }

    public function setLogin(string $login, string $password): bool
    {
        // Vérifie le login
        if (!self::isValidLogin($login)) {
            return false; // login invalide
        }

        // Vérifie le mot de passe
        if (!self::isStrongPassword($password)) {
            return false; // mot de passe trop faible
        }

        // Si tout est bon, on enregistre
        $this->login = $login;
        $this->password = $password;

        return true;
    }


    public function masquerLogin(): string
    { // Masque une partie du login
        $taille = mb_strlen($this->login); // Longueur du login

        if ($taille <= 4) {
            return str_repeat('*', $taille); // Si le login est court (≤4), tout est masqué
        }

        $debut = mb_substr($this->login, 0, 2); // Garde les 2 premiers caractères
        $fin = mb_substr($this->login, -2); // Garde les 2 derniers caractères
        $masque = str_repeat('*', $taille - 4); // Remplace le reste par des *

        return $debut . $masque . $fin; // Retourne une chaine de caractères
    }

    public function toArray(): array
    { // Retourne l'objet sous forme de tableau (debug)
        return [
            'login' => $this->login, // Login de l'objet
            'password' => $this->password // Mot de passe de l'objet
        ];
    }

    public function checkPassword(string $plain): bool
    { // Vérifie si le mot de passe correspond à la valeur donnée
        return $this->password === $plain; // Retourne true si les deux correspondent
    }

    public function changePassword(string $new): bool
    { // Change le mot de passe si le nouveau est valide
        if (!self::isStrongPassword($new)) {
            return false; // Retourne false si le mot de passe ne respecte pas le regex
        }
        $this->password = $new; // Met à jour le mot de passe avec la nouvelle valeur
        return true; // Retourne true si l'opération a réussi
    }

    public function __toString(): string
    { // Retourne une représentation textuelle de l'objet
        return "Login : {$this->login}, Password : {$this->password}"; // Construit et retourne la chaîne avec le login et le mot de passe
    }

    public static function isValidLogin(string $login): bool
    { // Vérifie si le login respecte le format attendu
        return preg_match('/^[A-Za-z0-9._-]{3,20}$/', $login) === 1; // Retourne true si le login correspond au regex
    }

    public static function isStrongPassword(string $pswd): bool
    { // Vérifie si le mot de passe est suffisamment sécurisé
        return preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{8,}$/', $pswd) === 1; // Retourne true si le mot de passe correspond au regex
    }

    public static function fromArray(array $row)
    { // Crée une instance de Compte à partir d'un tableau
        return new Compte($row['login'], $row['password']); // Retourne une nouvelle instance initialisée avec les données du tableau
    }

    public static function count()
    { // Retourne le nombre d'instances de Compte créées
        return self::$count; // Retourne la valeur actuelle du compteur
    }

    public static function resetCounter()
    { // Réinitialise le compteur d'instances
        self::$count = 0; // Met le compteur d'instances à 0
    }

    public static function cmpByLoginLen(Compte $a, Compte $b): int
    { // Compare deux comptes selon la longueur du login
        return strlen($a->login) <=> strlen($b->login); // Retourne -1, 0 ou 1 selon la comparaison
    }

    public function jsonSerialize(): mixed
    { // Sérialise l'objet en JSON en masquant le mot de passe
        return [
            'login' => $this->login, // Ajoute le login en clair
            'password' => str_repeat('*', strlen($this->password)) // Ajoute le mot de passe masqué par des *
        ];
    }

    public function __construct(string $login = "", string $password = "")
    { // Constructeur
        $this->login = $login; // Initialise le login
        $this->password = $password; // Initialise le mot de passe

        self::$count++; // Incrémente le compteur d'instances
    }

}

?>