<?php
require_once __DIR__ . '/../db.php';

function existe(PDO $pdo, string $login, string $password): bool
{
    // on récupère uniquement le hash du mot de passe pour ce login
    $sth = $pdo->prepare('SELECT password FROM users WHERE login = :login LIMIT 1');
    $sth->execute(['login' => $login]);
    $row = $sth->fetch(PDO::FETCH_ASSOC);

    if (!$row) { // Si aucun utilisateur avec ce login
        return false;
    }

    $hash = $row['password'];

    // vérification sécurisée du mot de passe
    return password_verify($password, $hash);
}

?>