<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="<?= BASE_URL ?>css/style.css">
  <title>Accueil</title>
</head>
<body>
  <h1>Bienvenue sur votre gestion de contacts</h1>

  <p><a href="<?= BASE_URL ?>index.php?page=add">Ajouter un contact</a></p>

  <input type="text" id="search" placeholder="Rechercher un contact...">

  <div id="results">
    <?php if (!empty($contacts)): ?>
      <ul>
        <?php foreach ($contacts as $c): $infos = $c->getContact(); ?>
          <li>
            <strong><?= htmlspecialchars($infos['prenom'] . ' ' . $infos['nom']) ?></strong>
            - <?= htmlspecialchars($infos['email']) ?>
            - <?= htmlspecialchars($infos['telephone']) ?>
            |
            <a href="<?= BASE_URL ?>index.php?page=view&id=<?= $infos['id'] ?>">Voir</a>
            <a href="<?= BASE_URL ?>index.php?page=edit&id=<?= $infos['id'] ?>">Modifier</a>
            <a href="<?= BASE_URL ?>index.php?page=delete&id=<?= $infos['id'] ?>">Supprimer</a>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p>Aucun contact trouvé.</p>
    <?php endif; ?>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
  $(function(){
    $("#search").on("keyup", function () {
      $.get("<?= BASE_URL ?>index.php", { page: "search", q: $(this).val() }, function (html) {
        $("#results").html(html);
      });
    });
  });
  </script>
</body>
</html>
