<?php
class Contact
{
    private int $id;
    private string $nom, $prenom, $email, $telephone;

    public function createContact(int $id, string $nom, string $prenom, string $email = "", string $telephone = ""): Contact
    {
        $contact = new Contact($id, $nom, $prenom, $email, $telephone);
        return $contact;
    }


    public function getContact(): array
    {
        return [
            "id" => $this->id,
            "nom" => $this->nom,
            "prenom" => $this->prenom,
            "email" => $this->email,
            "telephone" => $this->telephone
        ];
    }



    public function updateContact(int $id, string $nom, string $prenom, string $email, string $telephone): Contact
    {
        $this->id = $id;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->email = $email;
        $this->telephone = $telephone;

        return $this;
    }


    public function deleteContact()
    {
        $this->id = 0;
        $this->nom = "";
        $this->prenom = "";
        $this->email = "";
        $this->telephone = "";
    }

    public function __construct(int $id, string $nom, string $prenom, string $email = "", string $telephone = "")
    {
        $this->id = $id;
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->email = $email;
        $this->telephone = $telephone;
    }
}
?>