<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Suppression contact</title>
</head>

<body>
    <header>
    </header>
    <main>
        <h2>Supprimer un contact</h2>

        <?php if ($contact): ?>
            <?php $infos = $contact->getContact(); ?>
            <p>Voulez-vous vraiment supprimer le contact :</p>
            <p><strong><?= htmlspecialchars($infos['prenom']) ?>     <?= htmlspecialchars($infos['nom']) ?></strong></p>

            <form method="POST" action="">
                <button type="submit" name="confirm" value="yes">Oui, supprimer</button>
                <button type="submit" name="confirm" value="no">Non, annuler</button>
            </form>
        <?php else: ?>
            <p>❌ Contact introuvable.</p>
        <?php endif; ?>
        <p>
            <a href="../index.php"> Retour à la liste</a>
        </p>

    </main>
</body>

</html>