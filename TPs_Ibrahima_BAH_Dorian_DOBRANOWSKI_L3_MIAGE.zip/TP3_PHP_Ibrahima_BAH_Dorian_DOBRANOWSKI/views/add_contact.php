<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Ajouter un contact</title>
</head>

<body>
    <header>
    </header>
    <main>
        <h2>Ajouter un nouveau contact</h2>

        <form method="POST" action="">
            <label for="nom">Nom :</label>
            <input type="text" name="nom" id="nom" required><br><br>

            <label for="prenom">Prénom :</label>
            <input type="text" name="prenom" id="prenom" required><br><br>

            <label for="email">Email :</label>
            <input type="email" name="email" id="email"><br><br>

            <label for="telephone">Téléphone :</label>
            <input type="text" name="telephone" id="telephone"><br><br>

            <button type="submit">Enregistrer</button>
        </form>

        <p>
            <a href="HomeController.php">Retour à la liste</a>
        </p>


    </main>
</body>

</html>