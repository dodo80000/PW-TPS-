<?php
require_once __DIR__ . "/../../config/config.php";

class DAO
{
    private PDO $pdo;

    public function __construct()
    {
        try {
            $this->pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8",
                DB_USER,
                DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );

        } catch (PDOException $e) {
            die("Erreur de connexion à la BDD : " . $e->getMessage());
        }
    }

    public function createContact(Contact $c): bool
    {
        $contact = $c->getContact();
        $query = "INSERT INTO contacts (nom, prenom, email, telephone) 
              VALUES (:nom, :prenom, :email, :telephone)";
        $stmt = $this->pdo->prepare($query);
        return $stmt->execute([
            'nom' => $contact['nom'],
            'prenom' => $contact['prenom'],
            'email' => $contact['email'],
            'telephone' => $contact['telephone']
        ]);
    }

    public function findByIdContact(int $id): ?Contact
    {
        $query = "SELECT * FROM contacts WHERE id = :id";
        $stmt = $this->pdo->prepare($query);
        $stmt->execute(['id' => $id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            return new Contact(
                $result['id'],
                $result['nom'],
                $result['prenom'],
                $result['email'],
                $result['telephone']
            );
        }

        return null;
    }

    public function findAllContact(): array
    {
        $query = "SELECT * FROM contacts";
        $stmt = $this->pdo->query($query);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $contacts = [];
        foreach ($results as $row) {
            $contacts[] = new Contact(
                $row['id'],
                $row['nom'],
                $row['prenom'],
                $row['email'],
                $row['telephone']
            );
        }

        return $contacts;
    }

    public function updateContact(Contact $c): bool
    {
        $contact = $c->getContact();
        $query = "UPDATE contacts SET nom = :nom, prenom = :prenom, email = :email, telephone = :telephone WHERE id = :id";
        $stmt = $this->pdo->prepare($query);
        return $stmt->execute([
            'id' => $contact['id'],
            'nom' => $contact['nom'],
            'prenom' => $contact['prenom'],
            'email' => $contact['email'],
            'telephone' => $contact['telephone']
        ]);
    }

    public function deleteContact(Contact $c): bool
    {
        $contact = $c->getContact();
        $query = "DELETE FROM contacts WHERE id=:id";
        $stmt = $this->pdo->prepare($query);
        return $stmt->execute(['id' => $contact['id']]);
    }

    public function searchContacts(string $query): array
    {
        $sql = "SELECT * FROM contacts 
            WHERE nom LIKE :q OR prenom LIKE :q OR email LIKE :q OR telephone LIKE :q";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['q' => "%$query%"]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $contacts = [];
        foreach ($results as $row) {
            $contacts[] = new Contact(
                $row['id'],
                $row['nom'],
                $row['prenom'],
                $row['email'],
                $row['telephone']
            );
        }
        return $contacts;
    }


}

// $dao = new DAO();
// echo "Connexion réussie à la base de données !";
