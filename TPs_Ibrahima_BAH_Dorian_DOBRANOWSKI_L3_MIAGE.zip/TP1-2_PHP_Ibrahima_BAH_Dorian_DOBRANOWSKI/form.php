<!DOCTYPE html>
<html>
    <body>
        <form method='GET' action='indexbis.php'>
            <input type='login' name='login'>
            <input type='password' name='password'>
            <button>OK</button>
        </form>
</body>
</html>
