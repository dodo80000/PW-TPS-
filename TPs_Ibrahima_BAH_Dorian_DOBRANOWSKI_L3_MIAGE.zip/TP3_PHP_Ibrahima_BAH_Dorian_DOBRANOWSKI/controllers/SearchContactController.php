<?php
class SearchContactController {
    public function index(): void {
        $q = $_GET['q'] ?? '';
        $results = (new DAO())->searchContacts($q);

        if (!$results) { echo "<p>Aucun contact trouvé.</p>"; return; }

        echo "<ul>";
        foreach ($results as $c) {
            $i = $c->getContact();
            echo "<li>
                    <strong>" . htmlspecialchars($i['prenom'] . ' ' . $i['nom']) . "</strong>
                    - " . htmlspecialchars($i['email']) . "
                    - " . htmlspecialchars($i['telephone']) . "
                    |
                    <a href='" . BASE_URL . "index.php?page=view&id={$i['id']}'>Voir</a>
                    <a href='" . BASE_URL . "index.php?page=edit&id={$i['id']}'>Modifier</a>
                    <a href='" . BASE_URL . "index.php?page=delete&id={$i['id']}'>Supprimer</a>
                  </li>";
        }
        echo "</ul>";
    }
}
