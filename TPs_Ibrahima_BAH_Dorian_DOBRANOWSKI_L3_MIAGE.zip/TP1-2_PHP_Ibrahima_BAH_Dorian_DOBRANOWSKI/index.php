<?php
require_once __DIR__ . '/classes/Compte.php';

$c1 = new Compte("compte1", "123456"); // Création d'un compte
$c2 = new Compte("compte2", "654321"); // Création d'un compte

echo "Nombres d'instances : " . Compte::count() . "<br>"; // Affichage du compteur

echo "Login en brut : " . $c1->getLogin() . ", login masque : " . $c1->masquerLogin() . "<br>";

echo "login : " . $c1->getLogin() . "<br>";
$c1->setLogin("compte3", "mypswd123");
echo "nouveau login: " . $c1->getLogin() . "<br>";

echo "tableau de debug : " . json_encode($c1->toArray());
echo "<br>";
var_dump(Compte::isStrongPassword("Az123456")); // true
echo "<br>";
var_dump(Compte::isStrongPassword("ab")); // false (trop court)
echo "<br>";

Compte::resetCounter(); // Réinitialisation du compteur

$c4 = ["login" => "compte4", "password" => "Az123456"];
echo "nouveau compte en passant par la fonction fromArray : " . Compte::fromArray($c4);
echo "Instances après reset" . Compte::count() . "<br>";

echo "Check password c1 (attendu true) : ";
var_dump($c1->checkPassword("mypswd123"));

echo "Check password c1 (attendu false) : ";
var_dump($c1->checkPassword("wrongpwd"));

if ($c1->changePassword("NewPwd2025")) {
    echo "Mot de passe changé avec succès<br>";
} else {
    echo "Mot de passe trop faible<br>";
}

// Création d'un tableau de plusieurs comptes
$comptes = [
    new Compte("bob", "Bob123456"),
    new Compte("charlie_long", "Ch@rlie123"),
    new Compte("alice", "Azerty123")
];

usort($comptes, ["Compte", "cmpByLoginLen"]); // Trie le tableau de comptes par longueur de login

echo "Comptes triés par longueur du login :<br>"; // Affiche un titre
foreach ($comptes as $c) { // Boucle, pour chaque comptes faire ...
    echo $c . "<br>"; // Affiche chaque compte trié (appel implicite de __toString)
}

echo "Export JSON d'un compte : " . json_encode($c1) . "<br>"; // Affiche le compte $c1 au format JSON (utilise jsonSerialize)


?>