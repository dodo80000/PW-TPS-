<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Bienvenue</title>
</head>

<body>
    <header>
    </header>
    <main>
        <h2>Détails du contact</h2>

        <?php if ($contact): ?>
            <?php $infos = $contact->getContact(); ?>
            <ul>
                <li><strong>Nom :</strong> <?= htmlspecialchars($infos['nom']) ?></li>
                <li><strong>Prénom :</strong> <?= htmlspecialchars($infos['prenom']) ?></li>
                <li><strong>Email :</strong> <?= htmlspecialchars($infos['email']) ?></li>
                <li><strong>Téléphone :</strong> <?= htmlspecialchars($infos['telephone']) ?></li>
            </ul>

        <?php else: ?>
            <p>Contact introuvable</p>

        <?php endif; ?>
        <p>
            <a href="../index.php"> Retour à la liste</a>
        </p>

    </main>
</body>

</html>